package academy.bangkit.lumoapp.model

data class UserModel(
    var userId: String,
    var name: String,
    var token: String,
    var isLogin: Boolean
)
