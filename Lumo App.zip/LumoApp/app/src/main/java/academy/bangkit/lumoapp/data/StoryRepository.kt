package academy.bangkit.lumoapp.data

import academy.bangkit.lumoapp.api.ApiService
import academy.bangkit.lumoapp.database.StoryDatabase
import academy.bangkit.lumoapp.helper.setupToken
import academy.bangkit.lumoapp.model.ListStoriesRespond
import academy.bangkit.lumoapp.model.ListStory
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.*

class StoryRepository(
    private val storyDatabase: StoryDatabase,
    private val apiService: ApiService
) {
    fun getStory(token: String): LiveData<PagingData<ListStory>> {
        @OptIn(ExperimentalPagingApi::class)
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            remoteMediator = StoryRemoteMediator(storyDatabase, apiService, setupToken(token)),
            pagingSourceFactory = {
                storyDatabase.storyDao().getAllStory()
            }
        ).liveData
    }

    fun getAllStoriesWithLocation(token: String): LiveData<ListStoriesRespond> = liveData {
        emit(ListStoriesRespond(false, "", emptyList()))
        try {
            val bearerToken = setupToken(token)
            val response = apiService.getStoriesWithLocation(bearerToken)
            emit(response)
        } catch (e: Exception) {
            emit(ListStoriesRespond(true, e.message.toString(), emptyList()))
        }
    }


    companion object {
        @Volatile
        private var instance: StoryRepository? = null

        fun getInstance(storyDatabase: StoryDatabase, apiService: ApiService): StoryRepository {
            return instance ?: synchronized(this) {
                val storyRepo = StoryRepository(storyDatabase, apiService)
                instance = storyRepo
                storyRepo
            }
        }
    }
}