package academy.bangkit.lumoapp.helper

import academy.bangkit.lumoapp.api.ApiConfig
import academy.bangkit.lumoapp.data.StoryRepository
import academy.bangkit.lumoapp.database.StoryDatabase
import android.content.Context

object Injection {
    fun provideRepository(context: Context): StoryRepository {
        val database = StoryDatabase.getDatabase(context)
        val apiService = ApiConfig.getApiService()
        return StoryRepository.getInstance(database, apiService)
    }
}