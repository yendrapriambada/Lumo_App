package academy.bangkit.lumoapp.view.homepage

import academy.bangkit.lumoapp.api.ApiConfig
import academy.bangkit.lumoapp.data.StoryRepository
import academy.bangkit.lumoapp.helper.setupToken
import academy.bangkit.lumoapp.model.ListStoriesRespond
import academy.bangkit.lumoapp.model.ListStory
import academy.bangkit.lumoapp.model.UserModel
import academy.bangkit.lumoapp.model.UserPreference
import android.util.Log
import androidx.lifecycle.*
import androidx.paging.PagingData
import androidx.paging.cachedIn
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    private val _responseListWidget = MutableLiveData<ListStoriesRespond>()
    val responseListWidget: LiveData<ListStoriesRespond> = _responseListWidget

    fun getAllStories(token: String): LiveData<PagingData<ListStory>> {
        return storyRepository.getStory(token).cachedIn(viewModelScope)
    }

    fun getListForWidget(token: String) {
        val client = ApiConfig.getApiService().getAllStoriesForWidget(setupToken(token))
        client.enqueue(object : Callback<ListStoriesRespond> {
            override fun onResponse(
                call: Call<ListStoriesRespond>,
                response: Response<ListStoriesRespond>
            ) {
                if (response.isSuccessful) {
                    _responseListWidget.postValue(response.body())
                } else {
                    Log.e("MainViewModel", "isNotSuccess: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<ListStoriesRespond>, t: Throwable) {
                Log.e("MainViewModel", "onFailure: ${t.message.toString()}")
            }
        })
    }


    fun getUser(pref: UserPreference): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }

    fun logout(pref: UserPreference) {
        viewModelScope.launch {
            pref.logout()
        }
    }
}