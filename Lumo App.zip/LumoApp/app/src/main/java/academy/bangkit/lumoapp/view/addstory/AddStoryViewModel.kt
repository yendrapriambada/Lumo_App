package academy.bangkit.lumoapp.view.addstory

import academy.bangkit.lumoapp.api.ApiConfig
import academy.bangkit.lumoapp.helper.setupToken
import academy.bangkit.lumoapp.model.UploadStoryResponse
import academy.bangkit.lumoapp.model.UserModel
import academy.bangkit.lumoapp.model.UserPreference
import android.util.Log
import androidx.lifecycle.*
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddStoryViewModel(private val pref: UserPreference) : ViewModel() {
    private val _responseAddStory = MutableLiveData<UploadStoryResponse>()
    val responseAddStory: LiveData<UploadStoryResponse> = _responseAddStory

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _onFailure = MutableLiveData<String>()
    val onFailure: LiveData<String> = _onFailure

    companion object {
        private const val TAG = "AddStoryViewModel"
    }

    fun addStory(
        token: String,
        image: MultipartBody.Part,
        description: RequestBody,
        location: LatLng
    ) {
        val latitude = location.latitude.toString().toRequestBody("text/plain".toMediaType())
        val longitude = location.longitude.toString().toRequestBody("text/plain".toMediaType())
        _isLoading.value = true

        val client = ApiConfig.getApiService()
            .uploadStory(setupToken(token), image, description, latitude, longitude)
        client.enqueue(object : Callback<UploadStoryResponse> {
            override fun onResponse(
                call: Call<UploadStoryResponse>,
                response: Response<UploadStoryResponse>
            ) {
                _isLoading.postValue(false)
                if (response.isSuccessful) {
                    _responseAddStory.postValue(response.body())

                } else {
                    _responseAddStory.postValue(response.body())
                    _onFailure.postValue("Is Not Success: ${response.message()}")
                    Log.e(TAG, "isNotSuccess: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<UploadStoryResponse>, t: Throwable) {
                _isLoading.postValue(false)
                _onFailure.postValue("On Failure: ${t.message.toString()}")
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }

    fun getUser(): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            pref.logout()
        }
    }
}