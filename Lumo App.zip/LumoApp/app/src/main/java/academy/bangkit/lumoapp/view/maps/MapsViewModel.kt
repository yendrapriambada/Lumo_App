package academy.bangkit.lumoapp.view.maps

import academy.bangkit.lumoapp.data.StoryRepository
import academy.bangkit.lumoapp.model.ListStoriesRespond
import academy.bangkit.lumoapp.model.UserModel
import academy.bangkit.lumoapp.model.UserPreference
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData

class MapsViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    fun getAllStoriesWithLocation(token: String): LiveData<ListStoriesRespond> {
        return storyRepository.getAllStoriesWithLocation(token)
    }

    fun getUser(pref: UserPreference): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }
}