package academy.bangkit.lumoapp.database

import academy.bangkit.lumoapp.model.ListStory
import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface StoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(stories: List<ListStory>)

    @Query("SELECT * FROM tb_story")
    fun getAllStory(): PagingSource<Int, ListStory>

    @Query("DELETE FROM tb_story")
    suspend fun deleteAll()
}