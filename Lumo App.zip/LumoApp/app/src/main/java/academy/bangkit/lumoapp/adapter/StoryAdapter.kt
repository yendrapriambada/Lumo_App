package academy.bangkit.lumoapp.adapter

import academy.bangkit.lumoapp.R
import academy.bangkit.lumoapp.databinding.ItemRowStoryBinding
import academy.bangkit.lumoapp.helper.setProfilePicture
import academy.bangkit.lumoapp.helper.withDateFormat
import academy.bangkit.lumoapp.model.ListStory
import academy.bangkit.lumoapp.view.detailstory.DetailStoryActivity
import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class StoryAdapter :
    PagingDataAdapter<ListStory, StoryAdapter.StoryViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val binding =
            ItemRowStoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return StoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        val data = getItem(position)
        if (data != null) {
            holder.bind(data)
        }
    }

    class StoryViewHolder(private val binding: ItemRowStoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(listStory: ListStory) {
            with(binding) {
                val circularProgressDrawable = CircularProgressDrawable(itemView.context)
                circularProgressDrawable.strokeWidth = 5f
                circularProgressDrawable.centerRadius = 30f
                circularProgressDrawable.start()
                val urlRandomAvatar = setProfilePicture(listStory.name)
                val date = listStory.createdAt.withDateFormat()

                tvItemName.text = listStory.name
                tvDate.text =
                    itemView.context.getString(R.string.uploaded_on, date)
                tvDescription.text = listStory.description
                Glide.with(itemView.context)
                    .load(listStory.photoUrl)
                    .placeholder(circularProgressDrawable)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .error(R.mipmap.ic_launcher_round)
                    .into(imgStoryDetail)
                Glide.with(itemView.context)
                    .load(urlRandomAvatar)
                    .placeholder(circularProgressDrawable)
                    .error(R.mipmap.ic_launcher_round)
                    .into(profileImage)

                cvItemStory.setOnClickListener {
                    val intent = Intent(it.context, DetailStoryActivity::class.java)
                    intent.putExtra(DetailStoryActivity.EXTRA_NAME, tvItemName.text)
                    intent.putExtra(DetailStoryActivity.EXTRA_DATE, tvDate.text)
                    intent.putExtra(DetailStoryActivity.EXTRA_DESC, tvDescription.text)
                    intent.putExtra(DetailStoryActivity.EXTRA_STORY_IMG, listStory.photoUrl)
                    intent.putExtra(DetailStoryActivity.EXTRA_PROFILE_IMG, urlRandomAvatar)

                    val optionsCompat: ActivityOptionsCompat =
                        ActivityOptionsCompat.makeSceneTransitionAnimation(
                            itemView.context as Activity,
                            Pair(tvItemName, "name"),
                            Pair(tvDate, "date"),
                            Pair(tvDescription, "description"),
                            Pair(imgStoryDetail, "storyimage"),
                            Pair(profileImage, "profilepicture"),
                        )

                    it.context.startActivity(intent, optionsCompat.toBundle())
                }
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListStory>() {
            override fun areItemsTheSame(
                oldItem: ListStory,
                newItem: ListStory
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: ListStory,
                newItem: ListStory
            ): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }
}