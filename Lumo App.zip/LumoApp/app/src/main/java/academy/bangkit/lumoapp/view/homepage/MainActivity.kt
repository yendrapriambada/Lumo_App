package academy.bangkit.lumoapp.view.homepage

import academy.bangkit.lumoapp.R
import academy.bangkit.lumoapp.adapter.LoadingStateAdapter
import academy.bangkit.lumoapp.adapter.StoryAdapter
import academy.bangkit.lumoapp.databinding.ActivityMainBinding
import academy.bangkit.lumoapp.helper.ViewModelFactory
import academy.bangkit.lumoapp.helper.fetchData
import academy.bangkit.lumoapp.helper.getGreetingMessage
import academy.bangkit.lumoapp.model.UserPreference
import academy.bangkit.lumoapp.view.addstory.AddStoryActivity
import academy.bangkit.lumoapp.view.login.LoginActivity
import academy.bangkit.lumoapp.view.maps.MapsActivity
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import java.util.*

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {
    private val viewModel: MainViewModel by viewModels { ViewModelFactory(this) }
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: StoryAdapter
    private val list = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setupView()
        setContentView(binding.root)

        setupAdapter()
        setupAction()
        setupObserve()
        playAnimation()
    }

    private fun setupView() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        supportActionBar?.hide()
        when (Locale.getDefault().displayLanguage) {
            "English" -> binding.btnLanguage.setImageResource(R.drawable.us_flag)
            "Indonesia" -> binding.btnLanguage.setImageResource(R.drawable.in_flag)
            "español" -> binding.btnLanguage.setImageResource(R.drawable.spain_flag)
            else -> binding.btnLanguage.setImageResource(R.drawable.ic_baseline_language_24)
        }
    }

    private fun setupAdapter() {
        adapter = StoryAdapter()

        binding.rvStory.layoutManager = LinearLayoutManager(this)
        binding.rvStory.setHasFixedSize(true)
    }

    private fun setupAction() {
        binding.btnLogout.setOnClickListener {
            viewModel.logout(UserPreference.getInstance(dataStore))
            Toast.makeText(this, getString(R.string.logout_successful), Toast.LENGTH_SHORT).show()
        }
        binding.fabAdd.setOnClickListener {

        }
        binding.fabMaps.setOnClickListener {
            Intent(this@MainActivity, MapsActivity::class.java).also {
                startActivity(it)
            }
        }
        binding.fabAddStory.setOnClickListener {
            Intent(this@MainActivity, AddStoryActivity::class.java).also {
                startActivity(it)
            }
        }
        binding.btnLanguage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }
    }

    private fun setupObserve() {
        viewModel.getUser(UserPreference.getInstance(dataStore)).observe(this) { user ->
            if (user.isLogin) {
                binding.greeting1.text = getString(R.string.greeting, user.name)
                binding.greeting2.text = getGreetingMessage(this)
                viewModel.getListForWidget(user.token)

                binding.rvStory.adapter = adapter.withLoadStateFooter(
                    footer = LoadingStateAdapter {
                        adapter.retry()
                    }
                )

                viewModel.getAllStories(user.token).observe(this) { listStory ->
                    when {
                        listStory != null -> adapter.submitData(lifecycle, listStory)
                        else -> showLottie(true)
                    }
                }
                viewModel.responseListWidget.observe(this) {
                    var count = 0
                    if (it.error && it.listStory.isNullOrEmpty()) {
                        list.clear()
                    } else {
                        list.clear()
                        for (listPhotoUrl in it.listStory) {
                            list.add(listPhotoUrl.photoUrl)
                            count++
                            if (count > 3) {
                                break
                            }
                        }
                        fetchData(list)
                    }
                }

                adapter.addLoadStateListener { loadState ->
                    val isError =
                        loadState.refresh is LoadState.Error && loadState.source.refresh is LoadState.Error
                    val isLoading =
                        loadState.refresh is LoadState.Loading && loadState.source.refresh is LoadState.Loading

                    showLottie(isError)
                    showLoading(isLoading)
                }
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showLottie(isLottieVisible: Boolean) {
        binding.animationView.layoutDataEmpty.visibility =
            if (isLottieVisible) View.VISIBLE else View.GONE
    }

    private fun playAnimation() {
        val profilePic =
            ObjectAnimator.ofFloat(binding.profilePic, View.TRANSLATION_Y, -130f, 0f)
                .setDuration(500)
        val greeting1 =
            ObjectAnimator.ofFloat(binding.greeting1, View.TRANSLATION_Y, -130f, 0f)
                .setDuration(500)
        val greeting2 =
            ObjectAnimator.ofFloat(binding.greeting2, View.TRANSLATION_Y, -130f, 0f)
                .setDuration(500)
        val btnLanguage =
            ObjectAnimator.ofFloat(binding.btnLanguage, View.TRANSLATION_Y, -130f, 0f)
                .setDuration(500)
        val btnLogout =
            ObjectAnimator.ofFloat(binding.btnLogout, View.TRANSLATION_Y, -130f, 0f)
                .setDuration(500)

        AnimatorSet().apply {
            playTogether(profilePic, greeting1, greeting2, btnLanguage, btnLogout)
            start()
        }
    }
}