package academy.bangkit.lumoapp.view.addstory

import academy.bangkit.lumoapp.R
import academy.bangkit.lumoapp.databinding.ActivityAddStoryBinding
import academy.bangkit.lumoapp.helper.*
import academy.bangkit.lumoapp.model.UserPreference
import academy.bangkit.lumoapp.view.homepage.MainActivity
import academy.bangkit.lumoapp.view.login.LoginActivity
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Layout
import android.text.SpannableString
import android.text.style.AlignmentSpan
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.tasks.CancellationTokenSource
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.*

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class AddStoryActivity : AppCompatActivity() {
    private lateinit var viewModel: AddStoryViewModel
    private lateinit var binding: ActivityAddStoryBinding
    private var getFile: File? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var myLocLng: LatLng
    private val cts = CancellationTokenSource()

    companion object {
        const val CAMERA_X_RESULT = 200
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setupView()
        setContentView(binding.root)

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        setupViewModel()
        setupAction()
        setupObserve()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this,
                    getString(R.string.didnt_get_permission),
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun setupView() {
        setSupportActionBar(binding.toolbarAddstory)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        when (Locale.getDefault().displayLanguage) {
            "English" -> binding.btnLanguage.setImageResource(R.drawable.us_flag)
            "Indonesia" -> binding.btnLanguage.setImageResource(R.drawable.in_flag)
            "español" -> binding.btnLanguage.setImageResource(R.drawable.spain_flag)
            else -> binding.btnLanguage.setImageResource(R.drawable.ic_baseline_language_24)
        }
    }

    private fun setupViewModel() {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[AddStoryViewModel::class.java]
    }

    private fun setupAction() {
        binding.btnCamera.setOnClickListener {
            startCameraX()
        }

        binding.btnGallery.setOnClickListener {
            startGallery()
        }

        binding.btnUpload.setOnClickListener {
            uploadStory()
        }

        binding.btnLanguage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }

        binding.btnLogout.setOnClickListener {
            viewModel.logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            Toast.makeText(this, getString(R.string.logout_successful), Toast.LENGTH_SHORT).show()
        }

        binding.btnLocation.setOnClickListener {
            getMyLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getMyLocation() {
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.getCurrentLocation(
                LocationRequest.PRIORITY_HIGH_ACCURACY,
                cts.token
            ).addOnSuccessListener { location ->
                if (location != null) {
                    myLocLng = LatLng(location.latitude, location.longitude)
                    val address = getAddress(myLocLng)
                    binding.edtLocation.setText(address)
                } else {
                    showToast(this, getString(R.string.location_not_found))
                }
            }
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun getAddress(location: LatLng): String? {
        val geocoder = Geocoder(this)
        val allAddress = geocoder.getFromLocation(location.latitude, location.longitude, 1)
        return if (allAddress.isNotEmpty()) {
            allAddress[0].getAddressLine(0)
        } else {
            getString(R.string.empty_address)
        }
    }

    private fun setupObserve() {
        viewModel.responseAddStory.observe(this) {
            if (!it.error) {
                AlertDialog.Builder(this).apply {
                    val message = SpannableString(it.message)
                    val view = View.inflate(this@AddStoryActivity, R.layout.uploadsuccess, null)

                    message.setSpan(
                        AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER),
                        0,
                        title.length,
                        0
                    )
                    setTitle(message)
                    setView(view)
                    setPositiveButton(getString(R.string.continue_btn)) { _, _ ->
                        val intent = Intent(context, MainActivity::class.java)
                        intent.flags =
                            Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                        finish()
                    }
                    create()
                    show()
                }
            } else {
                Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.isLoading.observe(this) {
            showLoading(it)
        }

        viewModel.onFailure.observe(this) {
            AlertDialog.Builder(this).apply {
                setTitle(getString(R.string.sorry))
                setMessage(it)
                setPositiveButton(getString(R.string.try_again)) { dialog, _ ->
                    dialog.cancel()
                }
                create()
                show()
            }
        }
    }

    private fun uploadStory() {
        if (getFile != null) {
            val file = reduceFileImage(getFile as File)
            val inputDesc = binding.edtDescription.text.toString()
            if (inputDesc.isNotEmpty()) {
                val description = inputDesc.toRequestBody("text/plain".toMediaType())
                val address = binding.edtLocation.text.toString()
                val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                    "photo",
                    file.name,
                    requestImageFile
                )
                val location: LatLng = if (address.isEmpty()) {
                    LatLng(0.0, 0.0)
                } else {
                    getCoordinateLocation(address)
                }

                viewModel.getUser().observe(this) { user ->
                    if (user.isLogin) {
                        viewModel.addStory(user.token, imageMultipart, description, location)
                    } else {
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    }
                }
            } else {
                Toast.makeText(
                    this@AddStoryActivity,
                    getString(R.string.please_fill_in_the_description),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            Toast.makeText(
                this@AddStoryActivity,
                getString(R.string.no_picture_attached),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun getCoordinateLocation(address: String): LatLng {
        val randomLatitude = randomCoordinate()
        val randomLongitude = randomCoordinate()

        val geocoder = Geocoder(this)
        val locations = geocoder.getFromLocationName(address, 1)
        return if (locations.isNotEmpty()) {
            LatLng(locations[0].latitude, locations[0].longitude)
        } else {
            LatLng(randomLatitude, randomLongitude)
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, getString(R.string.choose_a_picture))
        launcherIntentGallery.launch(chooser)
    }

    private fun startCameraX() {
        val intent = Intent(this, CameraActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri

            val myFile = uriToFile(selectedImg, this@AddStoryActivity)

            getFile = myFile

            binding.imgStoryAdd.setImageURI(selectedImg)
            binding.previewImg.visibility = View.GONE
        }
    }

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = it.data?.getSerializableExtra("picture") as File
            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean

            getFile = myFile
            val result = rotateBitmap(
                BitmapFactory.decodeFile(getFile?.path),
                isBackCamera
            )
            binding.imgStoryAdd.setImageBitmap(result)
            binding.previewImg.visibility = View.GONE
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }
}