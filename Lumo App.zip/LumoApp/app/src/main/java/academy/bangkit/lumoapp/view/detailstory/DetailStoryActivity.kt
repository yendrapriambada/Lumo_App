package academy.bangkit.lumoapp.view.detailstory

import academy.bangkit.lumoapp.R
import academy.bangkit.lumoapp.databinding.ActivityDetailStoryBinding
import academy.bangkit.lumoapp.helper.ViewModelFactory
import academy.bangkit.lumoapp.model.UserPreference
import academy.bangkit.lumoapp.view.login.LoginActivity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import java.util.*

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class DetailStoryActivity : AppCompatActivity() {
    private lateinit var viewModel: DetailViewModel
    private lateinit var binding: ActivityDetailStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setupView()
        setContentView(binding.root)

        setupDataDetail()
        setupViewModel()
        setupAction()
    }

    private fun setupView() {
        setSupportActionBar(binding.toolbarDetail)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        when (Locale.getDefault().displayLanguage) {
            "English" -> binding.btnLanguage.setImageResource(R.drawable.us_flag)
            "Indonesia" -> binding.btnLanguage.setImageResource(R.drawable.in_flag)
            "español" -> binding.btnLanguage.setImageResource(R.drawable.spain_flag)
            else -> binding.btnLanguage.setImageResource(R.drawable.ic_baseline_language_24)
        }
    }

    private fun setupDataDetail() {
        val name = intent.getStringExtra(EXTRA_NAME)
        val date = intent.getStringExtra(EXTRA_DATE)
        val desc = intent.getStringExtra(EXTRA_DESC)
        val storyImage = intent.getStringExtra(EXTRA_STORY_IMG)
        val avatarImage = intent.getStringExtra(EXTRA_PROFILE_IMG)
        val circularProgressDrawable = CircularProgressDrawable(this)
        circularProgressDrawable.strokeWidth = 5f
        circularProgressDrawable.centerRadius = 30f
        circularProgressDrawable.start()

        binding.apply {
            tvItemName.text = name
            tvDate.text = date
            tvDescDetail.text = desc
            Glide.with(this@DetailStoryActivity)
                .load(storyImage)
                .placeholder(circularProgressDrawable)
                .error(R.mipmap.ic_launcher_round)
                .into(imgStoryDetail)
            Glide.with(this@DetailStoryActivity)
                .load(avatarImage)
                .placeholder(circularProgressDrawable)
                .error(R.mipmap.ic_launcher_round)
                .into(profileImage)
        }
    }

    private fun setupViewModel() {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[DetailViewModel::class.java]
    }

    private fun setupAction() {
        binding.btnLanguage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }

        binding.btnLogout.setOnClickListener {
            viewModel.logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            Toast.makeText(this, getString(R.string.logout_successful), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_DATE = "extra_date"
        const val EXTRA_DESC = "extra_desc"
        const val EXTRA_PROFILE_IMG = "extra_profile_img"
        const val EXTRA_STORY_IMG = "extra_story_img"
    }
}