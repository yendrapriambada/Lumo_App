package academy.bangkit.lumoapp.view.maps

import academy.bangkit.lumoapp.R
import academy.bangkit.lumoapp.databinding.ActivityMapsBinding
import academy.bangkit.lumoapp.helper.ViewModelFactory
import academy.bangkit.lumoapp.helper.setProfilePicture
import academy.bangkit.lumoapp.helper.withDateFormat
import academy.bangkit.lumoapp.model.ListStory
import academy.bangkit.lumoapp.model.UserPreference
import academy.bangkit.lumoapp.view.detailstory.DetailStoryActivity
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {
    private val viewModel: MapsViewModel by viewModels { ViewModelFactory(this) }
    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var listStoryWithLocation: List<ListStory>
    private val boundsBuilder = LatLngBounds.Builder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment

        setupObserve(mapFragment)
    }

    private fun setupObserve(mapFragment: SupportMapFragment) {
        viewModel.getUser(UserPreference.getInstance(dataStore)).observe(this) { user ->
            viewModel.getAllStoriesWithLocation(user.token).observe(this) {
                if (!it.error && it.message.isNotEmpty()) {
                    listStoryWithLocation = it.listStory
                    mapFragment.getMapAsync(this)
                }
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        setMapUI()
        setMapStyle()
        getMyLocation()
        setStoryWithLocation()
        setActionMarker()
    }

    private fun setMapUI() {
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true
    }

    private fun setMapStyle() {
        try {
            val success =
                mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style))
            if (!success) {
                Log.e(TAG, "Style parsing failed.")
            }
        } catch (exception: Resources.NotFoundException) {
            Log.e(TAG, "Can't find style. Error: ", exception)
        }
    }

    @SuppressLint("MissingPermission")
    private fun getMyLocation() {
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun setStoryWithLocation() {
        if (listStoryWithLocation.isNullOrEmpty()) return

        listStoryWithLocation.forEach { story ->
            val location = LatLng(story.lat, story.lon)
            val address = getAddress(location)
            val storyBy = getString(R.string.story_by, story.name)
            val marker = mMap.addMarker(
                MarkerOptions()
                    .position(location)
                    .title(storyBy)
                    .snippet(address)
            )

            boundsBuilder.include(location)
            marker?.tag = story

        }

        val bounds: LatLngBounds = boundsBuilder.build()
        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 10))
    }

    private fun setActionMarker() {
        mMap.setOnInfoWindowClickListener {
            val locationStory = it.tag as ListStory

            val intent = Intent(this@MapsActivity, DetailStoryActivity::class.java)
            intent.putExtra(DetailStoryActivity.EXTRA_STORY_IMG, locationStory.photoUrl)
            intent.putExtra(DetailStoryActivity.EXTRA_NAME, locationStory.name)
            intent.putExtra(DetailStoryActivity.EXTRA_DESC, locationStory.description)
            intent.putExtra(
                DetailStoryActivity.EXTRA_PROFILE_IMG,
                setProfilePicture(locationStory.name)
            )
            intent.putExtra(
                DetailStoryActivity.EXTRA_DATE,
                locationStory.createdAt.withDateFormat()
            )

            startActivity(intent)
        }
    }

    private fun getAddress(location: LatLng): String? {
        val geocoder = Geocoder(this)
        val allAddress = geocoder.getFromLocation(location.latitude, location.longitude, 1)
        return if (allAddress.isNotEmpty()) {
            allAddress[0].getAddressLine(0)
        } else {
            getString(R.string.empty_address)
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.map_options, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.normal_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                true
            }
            R.id.satellite_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                true
            }
            R.id.terrain_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
                true
            }
            R.id.hybrid_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
                true
            }
            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }

    companion object {
        private const val TAG = "MapsActivity"
    }
}