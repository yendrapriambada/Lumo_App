package academy.bangkit.lumoapp.helper

import academy.bangkit.lumoapp.model.UserPreference
import academy.bangkit.lumoapp.view.addstory.AddStoryViewModel
import academy.bangkit.lumoapp.view.detailstory.DetailViewModel
import academy.bangkit.lumoapp.view.homepage.MainViewModel
import academy.bangkit.lumoapp.view.login.LoginViewModel
import academy.bangkit.lumoapp.view.maps.MapsViewModel
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class ViewModelFactory : ViewModelProvider.NewInstanceFactory {
    private var pref: UserPreference? = null
    private var context: Context? = null

    constructor(pref: UserPreference) {
        this.pref = pref
    }

    constructor(context: Context) {
        this.context = context
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(DetailViewModel::class.java) -> {
                pref?.let { DetailViewModel(it) } as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                context?.let { Injection.provideRepository(it) }?.let { MainViewModel(it) } as T
            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                pref?.let { LoginViewModel(it) } as T
            }
            modelClass.isAssignableFrom(AddStoryViewModel::class.java) -> {
                pref?.let { AddStoryViewModel(it) } as T
            }
            modelClass.isAssignableFrom(MapsViewModel::class.java) -> {
                context?.let { Injection.provideRepository(it) }?.let { MapsViewModel(it) } as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }
}